from tkinter import *
import pickle
import nltk
import time
from nltk.stem.porter import PorterStemmer
ps=PorterStemmer()
import string 
string.punctuation
from nltk.corpus import stopwords
tfidf=pickle.load(open('vectorizer.pkl','rb'))
model=pickle.load(open('model.pkl','rb'))
def transform_text(text):
    text=text.lower()
    text=nltk.word_tokenize(text)
    y=[]
    for i in text:
        if i.isalnum():
            y.append(i)
    text=y[:]
    y.clear()
    for i in text:
        if i not in stopwords.words('english') and i not in string.punctuation:
            y.append(i)
    text=y[:]
    y.clear()
    for i in text:
        y.append(ps.stem(i))
    return " ".join(y)
def gets(val):
    tra_val=transform_text(val) 
    vec_ip=tfidf.transform([tra_val])
    output=model.predict(vec_ip)[0]
    if output==1:
        text1=Label(m,text="It is a spam message",bg='white',fg='red',bd=4)
    else:
        text1=Label(m,text="It is not a spam message",bg='white',fg='green',bd=4)
    text1.place(x=450,y=400)
    


m=Tk(className="Spam Detector")
m.configure(background="black")
m.geometry("970x620")

heading_title=Label(m,text="SMS Spam Project",fg='White',bg='black',font=('times new roman',28,'bold'))
heading_title.place(x=350,y=55)
text=Label(m,text="Enter a message and check whether it is spam or not",bg='Black',fg='White',bd=4,font=('times new roman',15,'bold'))
text.place(x=290,y=109)
txt=StringVar()
print(txt)
val=Entry(m,fg='black',bg='white',textvariable=txt,font=('times new roman',15,'bold'))
val.place(x=250,y=250,height=40,width=550)
button=Button(m,text='Submit',fg='black',bg='white',height=1,width=18,command=lambda:gets(val.get()),font=('times new roman',15,'bold'))
button.place(x=400,y=350)
m.mainloop()

